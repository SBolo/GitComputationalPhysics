#include <stdio.h>
#include <math.h>
#include <gsl/gsl_sf_gamma.h>
#include <gsl/gsl_sf_laguerre.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_eigen.h>

#define STEP 0.00001 //step sulla derivazione
#define STP 5e-4 //step sul plot
#define RMAX 10 //massima distanza
#define E_CONV 82.945 //coefficiente di conversione energia
#define GSL(F,x) (*((F)->function))(x,(F)->params)
#define L(n,a,x)  gsl_sf_laguerre_n(n,a,x)
#define ft(n) gsl_sf_fact(n) //vuole un unsigned int: fattoriale - ritorna double
#define sft(n) gsl_sf_doublefact(n) //di nuovo unsigned: semifattoriale - ritorna double
#define HIJ(x) Hij(F,V,P,x,i,j) //funzione integranda
#define S(i,j,a,b) simpson(F,V,P,i,j,a,b) //simpson per Hij
#define MATRIX(n,m) gsl_matrix_alloc(n,m) //genera la matrice
#define GET_ELEMENT(m,i,j) gsl_matrix_get (m,i,j) //ottenere l'elemento ij-esimo della matrice
#define SET_ELEMENT(m,i,j,x) gsl_matrix_set(m,i,j,x) //definire l'elemento ij-esimo della matrice
#define GET_VECTOR(v,i) gsl_vector_get(v,i) //estrae l'elemento i-esimo dal vettore


typedef struct {
	double (*function)(double x, void *params);
	void *params;
} gsl_function;

typedef struct {
    int n;
    double *norm;
    int dim;
    gsl_vector *eigenvalues; //vettore GSL: conterrà gli autovalori
    gsl_matrix *matrix; //matrice quadrata: da diagonalizzare
    gsl_matrix *eigenvectors; //matrice quadrata: contiene gli autovettori
    gsl_eigen_symmv_workspace *workspace; //spazio di memoria allocato per l'effettiva diagonalizzazione
} prms;

/*__________________________________________________FUNCTIONS_FOR_ANALYSIS________________________________________________*/
double simpson_integrate(double *psi, int N) { //solo per il test di normalizzazione corretta
	double h, k, res = 0;
	int i = 0;
	double f[N];
	
	for(i = 0; i < N; i++) {
		f[i] = psi[i] * pow(STP*i, 2.);
	}
	
        k = f[0] + 4 * f[1] + f[N-1] + 4 * f[N-2];
    
	for(i = 2; i < N-2; i+=2) {
		res += 4 * f[i] + 2 * f[i+1];
	}
	
        return (k + res) * (STP/3);
	
}

double d1(gsl_function *f, double x) { //derivata prima
    return (GSL(f,x - 2.*STEP) - 8. * GSL(f, x - STEP) + 8. * GSL(f, x + STEP) - GSL(f, x + 2. * STEP))/(12. * STEP);
}

double d2(gsl_function *f, double x) { //derivata seconda
    return (-GSL(f,x - 2.*STEP) + 16. * GSL(f, x - STEP) - 30. * GSL(f,x) + 16. * GSL(f, x + STEP) - GSL(f, x + 2. * STEP))/(12. * STEP * STEP);
}
/*______________________________________________________END_ANALYSIS____________________________________________________*/


double basis(double x, void *params) { //Base dell'oscillatore armonico 3D
    
    prms *P = (prms *)params;
    int n = P->n; //elemento da pescare
    double j = P->norm[n]; //elemento dell'array dei coefficienti di normalizzazione
    
    return j * exp(-x*x/2.) * L(n, 1./2., x*x);
}

double potential(double x, void *params) { //potenziale di Malfliet-Tjon
    return (2.379/x) * (7.39 * exp(-3.110 * x) - 3.22 * exp(-1.555 * x) );
}

double Hij(gsl_function *F, gsl_function *V, prms *P, double x, int i, int j) { //hamiltoniana
    
    P->n = j; //fisso il primo indice j per il calcolo delle derivate
    double dder = - (1./2.) * d2(F,x);
    double der = - (1./x) * d1(F,x);
    double pot = GSL(V,x) * GSL(F,x);
    
    P->n = i; //fisso il secondo indice i e rimoltiplico tutto
    
    return x * x * GSL(F,x) * (dder + der + pot);
    
}

double simpson(gsl_function *F, gsl_function *V, prms *P, int i, int j, double a, double b) {
    //integra in particolare l'hamiltoniana: non molto elegante, ma funziona
    
    //a,b estremi di integrazione
	double h = 0, somma = 0, m = 0, res = 0, risultato;
	int k = 0, t = 0, N = 1e5; //N = numero di campionamenti
	double f[N];
	
        h = (b-a)/(N); //passo di integrazione
	
    for(k = 0; k < N; k++) {
        f[k] = HIJ(a+k*h); //campionamento della funzione
    }
    
        m = f[0] + 4 * f[1] + f[N-1] + 4 * f[N-2];
    
    for(k = 2; k < N - 2; k += 2) {
        res += 4 * f[k] + 2 * f[k+1];
    }
	
        risultato = (m + res) * (h/3); //risultato dell'integrale
    
	return risultato;
}

double diagonalization(gsl_function *F, gsl_function *V, prms *P, double a, double b, int eval) { //routine di diagonalizzazione
    
    int h, k, eigen, sort;
    double norm, energy;
    
    gsl_matrix_set_zero(P->matrix);
    
    printf("\n");
    printf("\t#Riempio la matrice %d x %d\n", P->dim,P->dim);
    
    for(h = 0; h < P->dim; h++) {
        
        for(k = 0; k < P->dim; k++) {
            
            printf("\t%d posti riempiti su %d\r",(P->dim)*h + k, (P->dim)*(P->dim));
            fflush(stdout);
            
            SET_ELEMENT(P->matrix, h, k, S(h,k,a,b)); //inserisco gli elementi di matrice
            
        }
    }
    
    printf("\t#Matrice riempita: procedo alla diagonalizzazione\n");
    
        eigen = gsl_eigen_symmv(P->matrix, P->eigenvalues, P->eigenvectors, P->workspace); //diagonalizzo
        sort = gsl_eigen_symmv_sort(P->eigenvalues, P->eigenvectors, GSL_EIGEN_SORT_VAL_ASC); //ordino gli autovalori in ordine crescente
    
    printf("\t#Diangoanlizzata e ordinata: ecco il risultato, con P.dim = %d: \n", P->dim);
    
    return GET_VECTOR(P->eigenvalues, eval); //ritorna l'autovalore desiderato
    
}

double print(prms *P, gsl_function *F, double x) { //per il print della funzione d'onda in modulo quadro
    int h;
    double f = 0.;
    
    for(h = 0; h < P->dim; h++) {
        P->n = h; 
        f += GET_ELEMENT(P->eigenvectors,h,0) * GSL(F,x);
    }
    
    return f*f;
}


int main() {
    
    double x, integ, integ2, energy, energy_old;
    unsigned int i;
    double norm[100];
    int j;
    FILE *pt;
    
    gsl_function F, V;
    prms P;
    
    double *psi = (double *)malloc((RMAX/STP) * sizeof(double)); //funzione d'onda
    
    F.function = basis;
    F.params = &P;
    V.function = potential;
    V.params = NULL;
    P.norm = norm;
    
    for( i = 0; i <= 100; i++ ) { //costruisco un array con i coefficienti di normalizzazione per la base
        norm[i] = sqrt( sqrt(1./(4.*M_PI)) * pow(2.,i+3) * ft(i) / sft(2*i+1) ); //coefficienti di normalizzazione della base
    }
    
    //pt = fopen("energy1","w");
    
                        /* In questo momento il programma è settato per dare direttamente la soluzione stimata con DIM = 67 */
    
    P.dim = 67; //modificare qui per cambiare la dimensione della matrice
    
    /*
    energy = -2.;
    
    do {
        
       energy_old = energy*E_CONV; */
        
        P.eigenvalues = gsl_vector_alloc(P.dim);
        P.matrix = MATRIX(P.dim,P.dim);
        P.eigenvectors = MATRIX(P.dim,P.dim);
        P.workspace = gsl_eigen_symmv_alloc(P.dim);
    
            energy = diagonalization(&F, &V, &P, STEP, 1000., 0);
            printf("\t#ENERGIA: %.4f\n", energy*E_CONV);
    
            /*fprintf(pt,"%d \t %.4f\n",P.dim,energy*E_CONV);
    
    printf("\t#ENERGY_OLD: %.4f\n",energy_old);
    printf("\t#DIFFERENZA: %.4f\n", fabs(energy*E_CONV - energy_old)); */
    printf("\n");
    
    
       /* gsl_vector_free(P.eigenvalues);
        gsl_matrix_free(P.matrix);
        gsl_matrix_free(P.eigenvectors);
        gsl_eigen_symmv_free(P.workspace);
     
        
        (P.dim)++;
        
    } while ( P.dim <= 67 );
    
        printf("Energia definitiva: %.4f\n", energy*E_CONV);
    
    fclose(pt); */
    
    pt = fopen("wave_def","w");
    
    for( j = 0; j < RMAX/STP; j++) {
        psi[j] = print(&P,&F,j*STP);
        fprintf(pt,"%g \t %g\n", j*STP, psi[j]);
    }
    fclose(pt);
    
    gsl_vector_free(P.eigenvalues);
    gsl_matrix_free(P.matrix);
    gsl_matrix_free(P.eigenvectors);
    gsl_eigen_symmv_free(P.workspace);
    free(psi);
    
    
    
    return 0;
}
